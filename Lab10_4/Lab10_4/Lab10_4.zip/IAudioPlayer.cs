﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab10_4
{
    interface IAudioPlayer
    {
        void Play();
        }
    }

